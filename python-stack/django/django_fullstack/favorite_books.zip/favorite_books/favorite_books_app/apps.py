from django.apps import AppConfig


class FavoriteBooksAppConfig(AppConfig):
    name = 'favorite_books_app'
