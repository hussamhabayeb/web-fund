from django.apps import AppConfig


class ImsappConfig(AppConfig):
    name = 'imsapp'
